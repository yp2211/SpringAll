package org.example.entity;

import org.seasar.doma.Entity;

@Entity(immutable = true)
public class Example {

    final String id;
    
    final String name;
    
    final Integer age;

    public Example(String id, String name, Integer age) {
        this.id = id;
        this.name = name;
        this.age = age;
    }
}
