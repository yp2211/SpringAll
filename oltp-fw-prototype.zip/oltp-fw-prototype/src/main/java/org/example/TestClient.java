package org.example;

import com.tandem.ext.util.DataConversionException;
import com.tandem.tmf.Current;
import com.tandem.tsmp.TsmpFileSystemException;
import com.tandem.tsmp.TsmpSendException;
import com.tandem.tsmp.TsmpServer;
import com.tandem.tsmp.TsmpServerUnavailableException;
import com.tandem.util.FSException;
import org.nonstop.oltp.Configuration;
import org.nonstop.oltp.ConfigurationResolver;
import org.nonstop.oltp.OltpServer;
import org.nonstop.oltp.ServerArguments;
import org.nonstop.oltp.ServerProperties;
import org.nonstop.oltp.doma.DbConfig;

import java.lang.reflect.Array;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;

public class TestClient {

    public static void main(String[] args) {
        System.out.println(args.length);
        Arrays.stream(args).forEach(v -> System.out.println(v));
        TestClient client = new TestClient();
        String pathmonName = args[0];
        String serverClassName = args[1];
        client.send(pathmonName, serverClassName);
    }
    
    public void send(String pathmonName, String serverClassName) {

        System.out.println("pathsend setup");
        TsmpServer server = new TsmpServer(pathmonName, serverClassName);
        TestActionInputMessage input = new TestActionInputMessage();
        input.setId("111");
        input.setName("hogeta");
        input.setAge(3);
        byte[] bytes = new byte[0];
        try {
            bytes = input.marshal();
        } catch (DataConversionException e) {
            throw new RuntimeException(e);
        }

        ConfigurationResolver config = new ConfigurationResolver(new ServerArguments(new String[]{}), new ServerProperties("TestApp"));
        DbConfig dbConfig = new DbConfig(config);
        ExampleDao exampleDao = new ExampleDaoImpl(dbConfig);
        System.out.println("count record of Example table : " + exampleDao.count());
        
        Current transaction = new Current();
        try {
            System.out.println("new Current()");
            System.out.println("Current Transaction status : " + transaction.get_status());

            transaction.begin();

            System.out.println("begin");
            System.out.println("Current Transaction " + transaction.get_control().toString());
            System.out.println("Current Transaction status : " + transaction.get_status());
        } catch (FSException e) {
            throw new RuntimeException(e);
        }

        ByteBuffer buf = ByteBuffer.allocate(1000);
        int result = 0;
        try {
            System.out.println("pathsend call service...");
            result = server.service(bytes, bytes.length, buf.array());
        } catch (TsmpSendException | TsmpFileSystemException | TsmpServerUnavailableException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
        System.out.println("pathsend result length => " + result);
        System.out.println("pathsend result data => " + new String(buf.array()));

        try {
//            transaction.rollback_only();
            System.out.println("Current Transaction status : " + transaction.get_status());
            transaction.commit(false);
            System.out.println("commit");
            System.out.println("Current Transaction status : " + transaction.get_status());
        } catch (FSException e) {
            System.out.println("commit failed...");
            e.printStackTrace();
            throw new RuntimeException(e);
        }
        
        System.out.println("count record of Example table : " + exampleDao.count());
    }
}
