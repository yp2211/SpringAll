package org.example;

import com.tandem.ext.util.DataConversionException;
import org.nonstop.pathsend.InputMessage;
import org.nonstop.pathsend.OutputMessage;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

public class TestActionOutputMessage implements OutputMessage, InputMessage {

    private String message;

    public TestActionOutputMessage() {
    }

    public TestActionOutputMessage(String message) {
        this.message = message;
    }

    public String message() {
        return message;
    }

    @Override
    public int getLength() {
        return 40;
    }

    @Override
    public void unmarshal(byte[] bytes, int i) throws DataConversionException {
        this.message = new String(bytes);
    }

    @Override
    public byte[] marshal() {
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        os.write(String.format("%-40s", message).getBytes(StandardCharsets.UTF_8), 0, 40);
        return os.toByteArray();
    }

    @Override
    public byte[] marshal(byte[] bytes) throws DataConversionException {
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        os.write(String.format("%-40s", message).getBytes(StandardCharsets.UTF_8), 0, 40);
        return os.toByteArray();
    }
}
