package org.example;

import org.nonstop.oltp.Action;
import org.nonstop.oltp.ApplicationContext;
import org.nonstop.pathsend.PathsendAccessor;

public class TestPathsendAction implements Action<TestActionInputMessage, TestActionOutputMessage> {

    @Override
    public TestActionOutputMessage execute(ApplicationContext context, TestActionInputMessage inputMessage) {

        log("gateway action start...");
        
        TestActionInputMessage input = new TestActionInputMessage();
        input.setId(inputMessage.getId());
        input.setName(inputMessage.getName());
        input.setAge(inputMessage.getAge());

        PathsendAccessor<TestActionInputMessage, TestActionOutputMessage> pathsend =
                context.pathsend("$hiji", "mysvc", TestActionInputMessage.class, TestActionOutputMessage.class);
        TestActionOutputMessage reply = pathsend.service(input);

        log("gateway action end");
        
        return reply;
    }

    private void log(String message) {
        String threadName = Thread.currentThread().getName();
        System.out.println("[" + threadName + "] " + message);
    }
}
