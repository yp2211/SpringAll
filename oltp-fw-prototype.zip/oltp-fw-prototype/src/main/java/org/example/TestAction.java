package org.example;

import com.tandem.tmf.Current;
import com.tandem.util.FSException;
import org.example.entity.Example;
import org.nonstop.oltp.Action;
import org.nonstop.oltp.ApplicationContext;
import org.nonstop.pathsend.PathsendAccessor;
import org.seasar.doma.jdbc.criteria.context.Criterion;

import javax.sql.DataSource;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Random;
import java.util.concurrent.TimeUnit;

public class TestAction implements Action<TestActionInputMessage, TestActionOutputMessage> {

    @Override
    public TestActionOutputMessage execute(ApplicationContext context, TestActionInputMessage inputMessage) {
        log(String.format(" id: %s , name: %s , age: %d", inputMessage.getId(), inputMessage.getName(), inputMessage.getAge()));

//        try {
//            log("5 sec sleep...");
//            TimeUnit.SECONDS.sleep(5);
//        } catch (InterruptedException e) {
//            throw new RuntimeException(e);
//        }
        
        System.out.println("DB update start");
        
        Example record = new Example(inputMessage.getId(), inputMessage.getName(), inputMessage.getAge());
        ExampleDao exampleDao = new ExampleDaoImpl(context.dbConfig());
        exampleDao.insert(record);
        
        // DbConfig経由でのDB接続を検証するためのダミー実装
//        try {
//            DataSource dataSource = context.dbConfig().getDataSource();
//            Connection con = dataSource.getConnection();
//            PreparedStatement pstmt = con
//                    .prepareStatement("UPDATE EMP SET FNAME = ? WHERE ID = ?");
//            pstmt.setString(1, "FN" + new Random(System.currentTimeMillis()).nextInt(9999));
//            pstmt.setInt(2, 1);
            
//            PreparedStatement pstmt = con.prepareStatement("INSERT INTO EXAMPLE VALUES (?,?,?)");
//            pstmt.setString(1, inputMessage.getId());
//            pstmt.setString(2, inputMessage.getName());
//            pstmt.setInt(3, inputMessage.getAge());
//
//            pstmt.executeUpdate();
//            pstmt.close();
//            con.close();
//        } catch (Exception e) {
//            System.out.println("db error");
//            e.printStackTrace();
//            throw  new RuntimeException(e);
//        }

        // 手っ取り早く直接SQL/MXに接続して動作確認するためのダミー実装
//        try {
//            Connection con = DriverManager.getConnection("jdbc:sqlmx:");
//            PreparedStatement pstmt = con
//                    .prepareStatement("UPDATE EMP SET FNAME = ? WHERE ID = ?");
//
//            pstmt.setString(1, "FN" + new Random(System.currentTimeMillis()).nextInt(9999));
//            pstmt.setInt(2, 1);
//
//            pstmt.executeUpdate();
//            pstmt.close();
//            con.close();
//        } catch (Exception e) {
//            System.out.println("db error");
//            e.printStackTrace();
//            throw  new RuntimeException(e);
//        }
        
        System.out.println("DB update end");
        
        // // Pathsendでメッセージを送信する想定（テスト時はモックに差し替え）
        // PathsendAccessor<TestPathsendRequestMessage, TestPathsendReplyMessage> pathsend =
        //         PathsendRepository.get("hoge", TestPathsendRequestMessage.class, TestPathsendReplyMessage.class);
//        PathsendAccessor<TestPathsendRequestMessage, TestPathsendReplyMessage> pathsend =
//                context.pathsend("hoge", TestPathsendRequestMessage.class, TestPathsendReplyMessage.class);
//        TestPathsendReplyMessage reply = pathsend.service(new TestPathsendRequestMessage("request by pathsend"));
        
        // Pathsendの準備を省略するためダミー実装
        TestActionOutputMessage res = new TestActionOutputMessage("response : OK");

        log(res.message());
        return res;
    }

    private void log(String message) {
        String threadName = Thread.currentThread().getName();
        System.out.println("[" + threadName + "] " + message);
    }
}
