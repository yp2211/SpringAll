
package org.example;

import com.tandem.ext.util.DataConversionException;
import org.nonstop.pathsend.InputMessage;

public class TestPathsendReplyMessage implements InputMessage {

    private byte[] data;
    
    public byte[] data() {
        return data;
    }

    @Override
    public int getLength() {
        return 0;
    }

    @Override
    public void unmarshal(byte[] data, int i) throws DataConversionException {
        this.data = data;
    }
}
