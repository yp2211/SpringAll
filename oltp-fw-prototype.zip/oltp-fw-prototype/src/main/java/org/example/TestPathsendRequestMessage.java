package org.example;

import com.tandem.ext.util.DataConversionException;
import org.nonstop.pathsend.OutputMessage;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

public class TestPathsendRequestMessage implements OutputMessage {

    private final String message;

    public TestPathsendRequestMessage(String message) {
        this.message = message;
    }

    @Override
    public int getLength() {
        return 20;
    }

    @Override
    public byte[] marshal() {
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        os.write(String.format("%-40s", message).getBytes(StandardCharsets.UTF_8), 0, 40);
        return os.toByteArray();
    }

    @Override
    public byte[] marshal(byte[] bytes) throws DataConversionException {
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        os.write(String.format("%-40s", message).getBytes(StandardCharsets.UTF_8), 0, 40);
        return os.toByteArray();
    }
}
