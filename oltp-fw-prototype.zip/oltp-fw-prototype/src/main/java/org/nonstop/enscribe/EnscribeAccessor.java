package org.nonstop.enscribe;

/**
 * Enscribeをモックに差し替え可能にするためのインタフェース。
 * 
 * モックに差し替えるためにインタフェースを実装させるだけなので、
 * メソッドはEnscribeと同じになる想定。
 * ラッピング自体の実現性に問題はなさそうであったため、現時点では
 * 全部のメソッドを用意して試してはいない。
 */
public interface EnscribeAccessor {
    
    boolean isExistingFile();

    void purge();

    void crate();

    void createAltKeyFiles();

    void getFileInfo();

    int getMaxReadCount();

    void keyPosition();

    void open(int mode1, int mode2);

    void close();

    int read(byte[] buf);

    int read(byte[] buf, int readSize);

    void write(byte[] data);

    void write(byte[] data, int length);


}
