package org.nonstop.enscribe;

import com.tandem.ext.enscribe.EnscribeFile;

/**
 * インタフェースを実装するためのEnscribeのラッパー。
 * 
 * 基本的にはEnscribeのメソッドをそのまま呼ぶだけの想定。
 * 同名のEnscribeファイルの読込をキャッシュするかの検討は必要であるため、
 * もしキャッシュするならコンストラクタやフレームワーク側でクローズ処理などの
 * コントロールが必要。
 */
public class EnscribeWrapper implements EnscribeAccessor {

    private final EnscribeFile enscribeFile;

    public EnscribeWrapper(String fileName) {
        this.enscribeFile = new EnscribeFile(fileName);
    }
    
    @Override
    public boolean isExistingFile() {
        return false;
    }

    @Override
    public void purge() {

    }

    @Override
    public void crate() {

    }

    @Override
    public void createAltKeyFiles() {

    }

    @Override
    public void getFileInfo() {

    }

    @Override
    public int getMaxReadCount() {
        return 0;
    }

    @Override
    public void keyPosition() {

    }

    @Override
    public void open(int mode1, int mode2) {

    }

    @Override
    public void close() {

    }

    @Override
    public int read(byte[] buf) {
        return 0;
    }

    @Override
    public int read(byte[] buf, int readSize) {
        return 0;
    }

    @Override
    public void write(byte[] data) {

    }

    @Override
    public void write(byte[] data, int length) {

    }
}
