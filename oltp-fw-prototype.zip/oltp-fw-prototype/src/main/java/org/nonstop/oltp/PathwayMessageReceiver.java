package org.nonstop.oltp;

import com.tandem.ext.guardian.GuardianException;
import com.tandem.ext.guardian.Receive;
import com.tandem.ext.guardian.ReceiveInfo;
import com.tandem.ext.guardian.ReceiveNoOpeners;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

/**
 * $Receiveからメッセージを受信する
 */
public class PathwayMessageReceiver implements MessageReceiver<PathwayMessage> {

//    private int count = 3;

    private final Receive receiver;

    public PathwayMessageReceiver() {
        this.receiver = Receive.getInstance();
        receiver.setReceiveDepth(2);
        if (!receiver.isOpen()) {
            try {
                receiver.open();
            } catch (GuardianException | IllegalAccessException e) {
                throw new RuntimeException(e);
            }
        }
        
    }

    @Override
    public PathwayMessage read() {
        ByteBuffer buf = ByteBuffer.allocate(57344);
        try {
            int countRead = receiver.read(buf.array(), 57344);
            ReceiveInfo messageInfo = receiver.getLastMessageInfo();
            byte [] request = new byte[countRead];
            System.arraycopy(buf.array(), 0, request, 0, countRead);

            messageInfo.activateRequestTransID();
            
            return new PathwayMessage(receiver, messageInfo, request);
            
        } catch (GuardianException | ReceiveNoOpeners e) {
            e.printStackTrace();
            return null;
        }
        
        // 動作確認用に通信しない仮実装
//        if (count == 0) {
//            return null;
//        }

        // receive.receiveで読込
        // $RECEIVEから取得する想定のByte配列を返しておく
//        try {
//            ByteArrayOutputStream os = new ByteArrayOutputStream();
//            os.write(String.format("%03d", 1).getBytes(StandardCharsets.UTF_8));
//            os.write(String.format("%-40s", "テスト太郎").getBytes(StandardCharsets.UTF_8), 0, 40);
//            os.write(ByteBuffer.allocate(4).putInt(20).array());
//
//            count--;
//
//            return new PathwayMessage(ByteBuffer.wrap(os.toByteArray()));
//
//        } catch (IOException e) {
//            e.printStackTrace();
//            throw new RuntimeException(e);
//        }
    }
}
