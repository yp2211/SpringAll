package org.nonstop.oltp;

public interface Configuration {

    String get(String key);

    String get(String key, String deafultValue);
}
