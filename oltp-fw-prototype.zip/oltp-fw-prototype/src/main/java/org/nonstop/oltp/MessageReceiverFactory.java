package org.nonstop.oltp;

/**
 * メッセージを受信するオブジェクトのファクトリ。
 * @param <T>
 */
public interface MessageReceiverFactory<T extends MessageReceiver> {

    T create(Configuration config);
}
