package org.nonstop.oltp;

import com.tandem.ext.guardian.ReceiveInfo;
import com.tandem.tmf.Current;

import java.nio.ByteBuffer;
import java.util.concurrent.TimeUnit;

/**
 * メッセージ処理スレッド
 */
public class MessageThread implements Runnable {

    private final ApplicationContext context;

    private final ActionExecutor actionExecutor;

    private final Message message;

    public MessageThread(ApplicationContext context, ActionExecutor actionExecutor, Message message) {
        this.context = context;
        this.actionExecutor = actionExecutor;
        this.message = message;
    }

    @Override
    public void run() {
        log("MessageThread#run() START");
        // 受信したメッセージを業務アクションで処理する
        try {
            // 業務アクションはサーバ起動時に生成したものを使い回す想定のため、引き回しているものを使用する

            ReceiveInfo receiveInfo = ((PathwayMessage) message).messageInfo();
            receiveInfo.activateRequestTransID();
            Current transaction = new Current();
            try {
                System.out.println("Current Transaction " + transaction.get_control().toString());
            } catch (Exception e) {
                System.out.println("get_control() failed...");
                e.printStackTrace();
                throw e;
            }
            
            ByteBuffer output = actionExecutor.execute(message.data());
            log("action reply : " + output.array().length + "byte");
            
            // rollback_only呼び出したらロールバックしないと例外になるが検証するための仮実装
//            transaction.rollback_only();
            
            log("set rollback_only");
            
            // メッセージ処理スレッドから処理結果を返信する
            message.reply(output);
        } catch (Exception e) {
            String msg = "error : " + e.getMessage();
            e.printStackTrace();
            message.reply(ByteBuffer.wrap(msg.getBytes()));
        }

        log("MessageThread#run() END");
    }

    private void log(String message) {
        String threadName = Thread.currentThread().getName();
        System.out.println("[" + threadName + "] " + message);
    }
}
