package org.nonstop.oltp;

import java.nio.ByteBuffer;

/**
 * 受信したメッセージを表す
 */
public interface Message {

    ByteBuffer data();

    void reply(ByteBuffer data);
}
