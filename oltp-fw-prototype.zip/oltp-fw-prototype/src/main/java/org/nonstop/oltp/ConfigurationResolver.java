package org.nonstop.oltp;

public class ConfigurationResolver implements Configuration {

    private final ServerArguments args;

    private final ServerProperties props;

    public ConfigurationResolver(ServerArguments args, ServerProperties props) {
        this.args = args;
        this.props = props;
    }

    public String get(String key) {
        // 起動時引数や環境変数、プロパティ等から優先順位に沿って取得するのがよさそう
        return props.get(key);
    }

    public String get(String key, String defaultValue) {
        return props.get(key, defaultValue);
    }
}
