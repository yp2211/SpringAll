package org.nonstop.oltp;

import  java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * サーバ上で起動される本体。
 */
public class OltpServer {

    public static void main(String[] args) {
        ServerArguments serverArgs = new ServerArguments(args);
        OltpServer server = new OltpServer();
        server.startup(serverArgs);
    }

    public void startup(ServerArguments args) {
        log("OltpServer#startup() START");

        // アプリ名に対応する設定値を読み込む
        String appName = args.get("nss.oltp.app-name");
        if (appName == null) {
            throw new IllegalArgumentException("アプリ名が指定されていません");
        }
        ServerProperties props = new ServerProperties(appName);
        // 設定値持ち回り用のオブジェクトを生成する
        Configuration config = new ConfigurationResolver(args, props);
        ApplicationContext context = new ApplicationContext(config);
        // 業務アクションの生成
        ActionExecutor actionExecutor = new ActionExecutor(context);
        // メッセージ処理スレッドの起動
        ExecutorService messageThreadPool = createMessageThreadPool(config);
        // メッセージ受信オブジェクトの生成
        MessageReceiver<? extends Message> messageReceiver = createMessageReceiver(config);
        // メッセージ受信スレッドを生成して実行する
        // 1つしか実行しないのでプールを使う必要はないが、とりあえず合わせておく
        ReceiveThread receiveThread = new ReceiveThread(context, messageThreadPool, messageReceiver, actionExecutor);
        ExecutorService threadExecutor = Executors.newSingleThreadExecutor();
        threadExecutor.execute(receiveThread);
        threadExecutor.shutdown();

        log("OltpServer#startup() END");
    }

    private ExecutorService createMessageThreadPool(Configuration config) {
        String value = config.get("nss.oltp.message.thread-size", "5");
        ExecutorService executorService = Executors.newFixedThreadPool(Integer.parseInt(value));
        // prestartAllCoreThreadsを呼ばなくてもFixedThreadPoolなら起動しているかと思ったが起動していなさそう
        ((ThreadPoolExecutor) executorService).prestartAllCoreThreads();
        return executorService;
    }

    private MessageReceiver<? extends Message> createMessageReceiver(Configuration config) {
        MessageReceiverFactory<? extends MessageReceiver<? extends Message>> factory = createMessageReceiverFactory(config);
        return factory.create(config);
    }

    private MessageReceiverFactory<? extends MessageReceiver<? extends Message>> createMessageReceiverFactory(Configuration config) {
        String className = config.get("nss.oltp.receiver.factory-class-name");
        if (className == null) {
            return new PathwayMessageReceiverFactory();
        }
        try {
            return (MessageReceiverFactory<? extends MessageReceiver<? extends Message>>) Class.forName(className).newInstance();

        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }

    private void log(String message) {
        String threadName = Thread.currentThread().getName();
        System.out.println("[" + threadName + "] " + message);
    }
}
