package org.nonstop.oltp.doma;

import com.tandem.sqlmx.SQLMXDataSource;
import org.nonstop.oltp.Configuration;
import org.seasar.doma.jdbc.Config;
import org.seasar.doma.jdbc.dialect.Dialect;

import javax.sql.DataSource;

public class DbConfig implements Config {

    private DataSource dataSource;

    private final Dialect dialect;

    public DbConfig(Configuration config) {
        String dialect = config.get("nss.datasource.dialect");
        if (!dialect.equals("sqlmx")) {
            throw new IllegalStateException("not support dialect => " + dialect);
        }

        try {
            Class.forName("com.tandem.sqlmx.SQLMXDriver");
        } catch (ClassNotFoundException e) {
            System.out.println("Could not find JDBC/MX T2 Driver");
            throw new IllegalStateException(e);
        }

//        SimpleDataSource dataSource = new SimpleDataSource();
//        String url = "jdbc:sqlmx:";
//        dataSource.setUrl(url);
//        this.dataSource = dataSource;

        // SQL/MXで提供されているDataSourceクラスを使用すればシステムプロパティ等の設定は不要になる
        // どちらでも動くが、ローカルテストで差し替えを考慮するならSimpleDataSourceなどの方がよさそうではある
        SQLMXDataSource dataSource = new SQLMXDataSource();
        dataSource.setUrl("jdbc:sqlmx:");
        
//        try {
//            DriverManager.getConnection(url);
//        } catch (SQLException e) {
//            e.printStackTrace();
//            throw new RuntimeException(e);
//        }

        String catalog = config.get("nss.datasource.catalog");
        System.out.println("DB Configuration : catalog => " + catalog);
//        System.setProperty("jdbcmx.catalog", catalog);
        dataSource.setCatalog(catalog);

        String schema = config.get("nss.datasource.schema");
        System.out.println("DB Configuration : schema => " + schema);
//        System.setProperty("jdbcmx.schema", schema);
        dataSource.setSchema(schema);

        String user = config.get("nss.datasource.user");
        System.out.println("DB Configuration : user => " + user);
//        System.setProperty("jdbcmx.user", user);
        dataSource.setUser(user);

        String password = config.get("nss.datasource.password");
        System.out.println("DB Configuration : password => " + password);
//        System.setProperty("jdbcmx.password", password);
        dataSource.setPassword(password);

        this.dataSource = new DataSourceWithCloseDisabled(dataSource);
        this.dialect = new SqlmxDialect();
    }

    @Override
    public DataSource getDataSource() {
        return dataSource;
    }

    @Override
    public Dialect getDialect() {
        return dialect;
    }
}
