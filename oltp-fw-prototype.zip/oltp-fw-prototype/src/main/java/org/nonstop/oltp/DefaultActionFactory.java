package org.nonstop.oltp;

import org.nonstop.pathsend.InputMessage;
import org.nonstop.pathsend.OutputMessage;

/**
 * 業務アクションのインスタンスを生成するためのファクトリ実装。
 */
public class DefaultActionFactory implements ActionFactory {

    private final Action<InputMessage, OutputMessage> actionInstance;

    public DefaultActionFactory(Configuration config) {
        String className = config.get("nss.oltp.action.class-name");
        try {
            Class<?> actionType = Class.forName(className);
            if (!Action.class.isAssignableFrom(actionType)) {
                throw new IllegalStateException(
                        String.format("アクションクラスが %s インタフェースを実装していません", Action.class.getName()));
            }
            this.actionInstance = (Action<InputMessage, OutputMessage>) actionType.newInstance();

        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
            throw new IllegalStateException(
                    String.format("アクションの生成に失敗しました [%s]", className), e);
        }
    }

    @Override
    public Action<InputMessage, OutputMessage> create(Configuration config) {
        return actionInstance;
    }
}
