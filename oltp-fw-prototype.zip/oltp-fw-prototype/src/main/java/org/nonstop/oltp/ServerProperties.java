package org.nonstop.oltp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Properties;

/**
 * プロパティの設定値
 */
public class ServerProperties {

    private final Properties props;

    public ServerProperties(String appName) {
        // サーバ起動時に指定したアプリ名から対応するプロパティファイルを読み込む
        // アプリごとにJARをわけるのか同じにまとめるのかは未定なので、とりあえず指定できるようにしている
        InputStream stream = Thread.currentThread().getContextClassLoader().getResourceAsStream(appName + ".properties");
        if (stream == null) {
            throw new IllegalStateException(String.format("プロパティファイルが見つかりません [%s]", appName));
        }

        BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8));
        Properties props = new Properties();
        try {
            props.load(reader);
        } catch (IOException e) {
            throw new IllegalStateException(String.format("プロパティファイルの読込に失敗しました [%s]", appName), e);
        }

        // 必須プロパティはこの時点でチェックしておくのがよさそう
        this.props = props;
    }

    public String get(String key) {
        return props.getProperty(key);
    }

    public String get(String key, String defaultValue) {
        return props.getProperty(key, defaultValue);
    }
}
