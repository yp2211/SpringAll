package org.nonstop.oltp;

/**
 * $Receiveからメッセージを受信するオブジェクトのファクトリ。
 */
public class PathwayMessageReceiverFactory implements MessageReceiverFactory<PathwayMessageReceiver> {

    @Override
    public PathwayMessageReceiver create(Configuration config) {
        // getInstance() と open()が呼ばれる
        return new PathwayMessageReceiver();
    }
}
