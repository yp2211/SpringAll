package org.nonstop.oltp;

import com.tandem.ext.util.DataConversionException;
import org.nonstop.pathsend.InputMessage;
import org.nonstop.pathsend.OutputMessage;

import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.Arrays;

/**
 * 業務アクションに関する情報群
 */
public class ActionExecutor {

    private final ApplicationContext context;

    private final Action<InputMessage, OutputMessage> actionInstance;

    private final Class<? extends InputMessage> inputMessageType;

    public ActionExecutor(ApplicationContext context) {
        this.context = context;
        // メッセージ受信時のコストを下げるため、出来る範囲でオブジェクトを生成しておく
        // 業務アクションクラスはスレッドセーフな実装を選定にして、最初に生成したインスタンスを使い回す想定
        this.actionInstance = createActionInstance(context.config());
        this.inputMessageType = resolveInputMessageType(actionInstance);
    }

    public ByteBuffer execute(ByteBuffer data) {
        // 業務アクションでメッセージを処理する
        try {
            InputMessage inputMessage = inputMessageType.newInstance();
            inputMessage.unmarshal(data.array(), data.array().length);

            OutputMessage res = actionInstance.execute(context, inputMessage);

            return ByteBuffer.wrap(res.marshal());

        } catch (Exception e) {
            // ロールバックのマークさせる
            System.out.println("actionInstance.execute() failed...");
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }

    private static Action<InputMessage, OutputMessage> createActionInstance(Configuration config) {
        ActionFactory factory = craeteActionFactory(config);
        return factory.create(config);
    }

    private static ActionFactory craeteActionFactory(Configuration config) {
        String className = config.get("nss.oltp.action.factory-class-name");
        if (className == null) {
            return new DefaultActionFactory(config);
        }
        try {
            Class<?> actionType = Class.forName(className);
            return actionType.asSubclass(ActionFactory.class).newInstance();
        } catch (ClassNotFoundException | ClassCastException | InstantiationException | IllegalAccessException e) {
            throw new IllegalStateException(
                    String.format("アクションファクトリの生成に失敗しました [%s]", className), e);
        }
    }

    private static Class<? extends InputMessage> resolveInputMessageType(Action<?, ?> actionInstance) {
        // もっとよいメソッドの解決手段があると思うが、一旦は簡易に解決
        Method actionMethod = Arrays.stream(actionInstance.getClass().getDeclaredMethods())
                .filter(v -> v.getName().equals("execute"))
                .filter(v -> v.getParameterCount() == 2)
                .filter(v -> v.getParameterTypes()[0].equals(ApplicationContext.class))
                .filter(v -> InputMessage.class.isAssignableFrom(v.getParameterTypes()[1]))
                .findFirst()
                .orElseThrow(() -> new IllegalStateException(
                        String.format("アクションメソッドが見つかりません [%s]", actionInstance.getClass().getName())));

        return (Class<? extends InputMessage>) actionMethod.getParameterTypes()[1];
    }
}
