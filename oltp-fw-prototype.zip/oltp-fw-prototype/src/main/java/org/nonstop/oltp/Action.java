package org.nonstop.oltp;

import org.nonstop.pathsend.InputMessage;
import org.nonstop.pathsend.OutputMessage;

/**
 * 業務アクションで実装してもらうインタフェース
 *
 * @param <T> 入力メッセージ
 * @param <U> 出力メッセージ
 */
public interface Action<T extends InputMessage, U extends OutputMessage> {

    U execute(ApplicationContext context, T inputMessage);
}
