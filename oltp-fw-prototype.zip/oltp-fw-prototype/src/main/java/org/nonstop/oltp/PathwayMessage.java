package org.nonstop.oltp;

import com.tandem.ext.guardian.GError;
import com.tandem.ext.guardian.GuardianException;
import com.tandem.ext.guardian.Receive;
import com.tandem.ext.guardian.ReceiveInfo;

import java.nio.ByteBuffer;

/**
 * $Receiveから受信したメッセージ
 */
public class PathwayMessage implements Message {

    private final ByteBuffer data;
    private final Receive receiver;
    private final ReceiveInfo messageInfo;
    
    public PathwayMessage(Receive receiver, ReceiveInfo messageInfo, byte[] bytes) {

        this.receiver = receiver;
        this.messageInfo = messageInfo;
        this.data = ByteBuffer.wrap(bytes);
    }

    @Override
    public ByteBuffer data() {
        return data;
    }

    @Override
    public void reply(ByteBuffer data) {
        try {
            receiver.reply(data.array(), data.array().length, messageInfo, GError.EOK);
        } catch (GuardianException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        }
    }
    
    public ReceiveInfo messageInfo() {
        return messageInfo;
    }
}
