package org.nonstop.oltp;

/**
 * メッセージを受信するためのオブジェクトを表す
 *
 * @param <T> 入力メッセージ
 */
public interface MessageReceiver<T extends Message> {

    T read();
}
