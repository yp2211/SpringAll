package org.nonstop.oltp;

import java.util.concurrent.ExecutorService;

/**
 * メッセージ受信スレッド
 */
public class ReceiveThread implements Runnable {

    private final ApplicationContext context;

    private final ExecutorService messageThreadPool;

    private final MessageReceiver<? extends Message> messageReceiver;

    private final ActionExecutor actionExecutor;

    public ReceiveThread(ApplicationContext context,
                         ExecutorService messageThreadPool,
                         MessageReceiver<? extends Message> messageReceiver,
                         ActionExecutor actionExecutor) {
        this.context = context;
        this.messageThreadPool = messageThreadPool;
        this.messageReceiver = messageReceiver;
        this.actionExecutor = actionExecutor;
    }

    @Override
    public void run() {
        log("ReceiveThread#run() START");

        // メッセージが受信できなくなるまで受信しつづける
        while (true) {
            // メッセージ受信待ちして、受信しなければ null が返ってくる想定
            Message message = messageReceiver.read();
            if (message == null) {
                log("read end");
                break;
            }
            log("action reply : " + message.data().array().length + "byte");

            // 受信したメッセージは別スレッドで並列処理する
            // （スレッドは起動しているため処理割当のみ）
            messageThreadPool.execute(new MessageThread(context, actionExecutor, message));
        }

        messageThreadPool.shutdown();

        log("ReceiveThread#run() END");
    }

    private void log(String message) {
        String threadName = Thread.currentThread().getName();
        System.out.println("[" + threadName + "] " + message);
    }
}
