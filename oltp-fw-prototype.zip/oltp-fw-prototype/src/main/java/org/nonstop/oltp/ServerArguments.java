package org.nonstop.oltp;

import java.util.HashMap;
import java.util.Map;

/**
 * サーバ起動時に指定した引数
 */
public class ServerArguments {

    private final Map<String, String> map = new HashMap<>();

    public ServerArguments(String[] args) {
        for (String arg: args) {
            System.out.println("parameter : " + arg);
            if (!arg.contains("=")) {
                throw new IllegalArgumentException(String.format("パラメータの形式が不正です [%s]", arg));
            }
            String[] tokens = arg.split("=");
            if (tokens.length != 2) {
                throw new IllegalArgumentException(String.format("パラメータの形式が不正です [%s]", arg));
            }
            this.map.put(tokens[0].trim(), tokens[1].trim());
        }
    }

    public String get(String key) {
        return map.get(key);
    }
}
