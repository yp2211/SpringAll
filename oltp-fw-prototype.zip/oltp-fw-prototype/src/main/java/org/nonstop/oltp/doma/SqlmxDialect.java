package org.nonstop.oltp.doma;

import org.seasar.doma.jdbc.dialect.StandardDialect;

/**
 * SQL/MX用のDialect。
 * 
 * 動作確認だけしたためまだ何も実装していない
 */
public class SqlmxDialect extends StandardDialect {

}
