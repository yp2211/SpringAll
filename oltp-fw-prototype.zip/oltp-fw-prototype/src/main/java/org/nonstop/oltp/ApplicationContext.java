package org.nonstop.oltp;

import org.nonstop.enscribe.EnscribeAccessor;
import org.nonstop.enscribe.EnscribeWrapper;
import org.nonstop.oltp.doma.DbConfig;
import org.nonstop.pathsend.InputMessage;
import org.nonstop.pathsend.OutputMessage;
import org.nonstop.pathsend.PathsendAccessor;
import org.nonstop.pathsend.PathsendAccessorFactory;
import org.nonstop.pathsend.PathsendWrapperFactory;
import org.seasar.doma.jdbc.Config;

public class ApplicationContext {

    private final Configuration config;

    private Config dbConfig;

    private final PathsendAccessorFactory pathsendAccessorFactory;

    public ApplicationContext(Configuration config) {
        this.config = config;
        this.dbConfig = new DbConfig(config);
        this.pathsendAccessorFactory = createPathsendAccessorFactory(config);
    }

    protected PathsendAccessorFactory createPathsendAccessorFactory(Configuration config) {
        String className = config.get("nss.pathsend.factory-class-name");
        if (className == null) {
            return new PathsendWrapperFactory();
        }
        try {
            Class<?> factoryType = Class.forName(className);
            return factoryType.asSubclass(PathsendWrapperFactory.class).newInstance();

        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
            throw new IllegalStateException(
                    String.format("ファクトリの生成に失敗しました [%s]", className), e);
        }
    }

    public Configuration config() {
        return config;
    }

    public <T extends OutputMessage, U extends InputMessage> PathsendAccessor<T, U> pathsend(String pathmonName, String serverName, Class<T> requestMessageType, Class<U> replyMessageType) {
        return pathsendAccessorFactory.create(pathmonName, serverName, requestMessageType, replyMessageType);
    }

    public EnscribeAccessor enscribe(String fileName) {
        // factoryを経由しないで実装する方法で検証
        // キャッシュとか考えるとfactoryを使うのがよさそうだが、実現できるのはわかっているのでここでは端折る
        return new EnscribeWrapper(fileName);
    }

    public Config dbConfig() {
        return dbConfig;
    }
}
