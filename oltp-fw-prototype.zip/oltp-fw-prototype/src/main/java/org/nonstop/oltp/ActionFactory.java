package org.nonstop.oltp;

import org.nonstop.pathsend.InputMessage;
import org.nonstop.pathsend.OutputMessage;

/**
 * 業務アクションのインスタンスを生成するためのファクトリ。
 */
public interface ActionFactory {

    Action<InputMessage, OutputMessage> create(Configuration config);
}
