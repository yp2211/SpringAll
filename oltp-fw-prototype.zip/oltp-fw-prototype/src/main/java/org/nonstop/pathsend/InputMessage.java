package org.nonstop.pathsend;

import com.tandem.ext.guardian.GuardianInput;

public interface InputMessage extends GuardianInput {

}
