package org.nonstop.pathsend.testing;

import org.junit.jupiter.api.extension.AfterEachCallback;
import org.junit.jupiter.api.extension.BeforeEachCallback;
import org.junit.jupiter.api.extension.ExtensionContext;
import org.nonstop.oltp.ApplicationContext;
import org.nonstop.oltp.Configuration;
import org.nonstop.oltp.ConfigurationResolver;
import org.nonstop.oltp.ServerArguments;
import org.nonstop.oltp.ServerProperties;
import org.nonstop.pathsend.InputMessage;
import org.nonstop.pathsend.OutputMessage;
import org.nonstop.pathsend.PathsendAccessorFactory;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;

public class OltpContextExtension implements BeforeEachCallback, AfterEachCallback {

    private final Map<String, Function<? extends OutputMessage, ? extends InputMessage>> pashsendMocks = new HashMap<>();

    @Override
    public void beforeEach(ExtensionContext extensionContext) throws Exception {
        // システムプロパティで任意のFactoryに差し替えて初期化できることは確認したので、
        // staticのRepositoryを提供して実装することはできそう。
        // PathsendMockFactoryを単純に返すだけでもいい気がするので、一旦そっちに切り替えてコメントアウト。
        // System.setProperty("nss.pathsend.factory-class-name", PathsendMockFactory.class.getName());
        // Method method = PathsendRepository.class.getDeclaredMethod("initialize");
        // method.setAccessible(true);
        // method.invoke(null);

        pashsendMocks.clear();
    }

    @Override
    public void afterEach(ExtensionContext extensionContext) throws Exception {
        pashsendMocks.clear();
    }

    public <T extends OutputMessage, U extends InputMessage> void registerPathsend(String pathmonName, String serverName, Function<T, U> mock) {
        pashsendMocks.put(pathmonName + "#" + serverName, mock);
    }

    public ApplicationContext crateMockContext(String appName) {
        // factoryは簡易的に差し替えたが、差し替え方法はもっと考えた方がよい
        ServerProperties props = new ServerProperties(appName);
        ConfigurationResolver config = new ConfigurationResolver(new ServerArguments(new String[]{}), props);
        ApplicationContext context = new ApplicationContext(config) {
            @Override
            protected PathsendAccessorFactory createPathsendAccessorFactory(Configuration config) {
                return new PathsendMockFactory(pashsendMocks);
            }
        };
        return context;
    }
}
