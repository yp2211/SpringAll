package org.nonstop.pathsend;

/**
 * Pathsendへのアクセサ。
 *
 * テストで差し替える想定のためインタフェースを切り出している。
 *
 * @param <T> 入力メッセージ
 * @param <U> 出力メッセージ
 */
public interface PathsendAccessor<T extends OutputMessage, U extends InputMessage> {

     U service(T request);
}
