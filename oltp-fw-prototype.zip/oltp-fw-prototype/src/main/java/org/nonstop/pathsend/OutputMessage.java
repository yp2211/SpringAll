package org.nonstop.pathsend;

import com.tandem.ext.guardian.GuardianOutput;

public interface OutputMessage extends GuardianOutput {
    
}
