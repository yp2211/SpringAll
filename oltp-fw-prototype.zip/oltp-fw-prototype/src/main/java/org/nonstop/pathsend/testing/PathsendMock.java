package org.nonstop.pathsend.testing;

import org.nonstop.pathsend.InputMessage;
import org.nonstop.pathsend.OutputMessage;

import java.util.function.Function;

public interface PathsendMock extends Function<OutputMessage, InputMessage> {
}
