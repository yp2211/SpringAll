package org.nonstop.pathsend.testing;

import org.nonstop.pathsend.InputMessage;
import org.nonstop.pathsend.OutputMessage;
import org.nonstop.pathsend.PathsendAccessor;

import java.util.function.Function;

public class PathsendMockAccessor<T extends OutputMessage, U extends InputMessage> implements PathsendAccessor<T, U> {

    private final Function<T, U> mock;

    public PathsendMockAccessor(Function<T, U> mock) {
        this.mock = mock;
    }

    @Override
    public U service(T request) {
        return mock.apply(request);
    }
}
