package org.nonstop.pathsend;

/**
 * Pathsendを使用するアクセスを生成するためのファクトリ実装。
 */
public class PathsendWrapperFactory implements PathsendAccessorFactory {

    @Override
    public <T extends OutputMessage, U extends InputMessage> PathsendAccessor<T, U> create(
            String pathmonName, String serverName, Class<T> requestMessageType, Class<U> replyMessageType) {
        return new PathsendWrapper(pathmonName, serverName, requestMessageType, replyMessageType);
    }
}
