package org.nonstop.pathsend;

/**
 * 業務アプリからPathsendのアクセサを取得するための置き場。
 *
 * ※ApplicationContextからではなくstaticアクセスでFactoryを取得できるようにしようと思ってつくったが、
 * ※staticアクセスは初期化等が複雑になるし使い方も分かりづらいので実装できることだけ確認して使用していない

 * Nablarchで作成するバッチやAPIと共有したいため、OLTPフレームワークには依存しない実装にしたい。
 * OLTPフレームワークにはDIコンテナ等は無いため、引数で渡すかstaticで取得するくらいしかなさそう。
 * 引数で渡すとしたらNablarchとの共有が難しそうなので、staticで取得するための置き場を用意しておく。
 */
public class PathsendRepository {

    private static PathsendAccessorFactory factory;

    public static <T extends OutputMessage, U extends InputMessage> PathsendAccessor<T, U> get(
            String pathmonName, Class<T> requestMessageType, Class<U> replyMessageType) {
        if (factory == null) {
            initialize();
        }
        // TsmpServerが再利用しても大丈夫そうならプールしてもいいかも
        return factory.create(pathmonName, "dummy", requestMessageType, replyMessageType);
    }

    private static void initialize() {
        // 方法は色々有りそうだが、一旦システムプロパティを経由して差し替え可能にしておく
        String factoryClassName = getFactoryClassName();
        try {
            Class<PathsendAccessorFactory> factoryType =
                    (Class<PathsendAccessorFactory>) Class.forName(factoryClassName);

            factory = factoryType.newInstance();

        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException e) {
            throw new IllegalStateException(
                    String.format("ファクトリの生成に失敗しました [%s]", factoryClassName), e);
        }
    }

    private static String getFactoryClassName() {
        return System.getProperty("nss.pathsend.factory-class-name", PathsendWrapperFactory.class.getName());
    }
}
