package org.nonstop.pathsend;

import com.tandem.ext.util.DataConversionException;
import com.tandem.tsmp.TsmpFileSystemException;
import com.tandem.tsmp.TsmpRoutUnavailableException;
import com.tandem.tsmp.TsmpSendException;
import com.tandem.tsmp.TsmpServer;
import com.tandem.tsmp.TsmpServerUnavailableException;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

/**
 * Pathsendを使用するためのアクセサ。
 *
 * @param <T> 入力メッセージ
 * @param <U> 出力メッセージ
 */
public class PathsendWrapper<T extends OutputMessage, U extends InputMessage> implements PathsendAccessor<T, U> {

    private final String pathmonName;

    private final String serverName;
    
    private final Class<T> requestMessageType;

    private final Class<U> replyMessageType;

    private final TsmpServer server;
    
    public PathsendWrapper(String pathmonName, String serverName, Class<T> requestMessageType, Class<U> replyMessageType) {
        this.pathmonName = pathmonName;
        this.serverName = serverName;
        this.requestMessageType = requestMessageType;
        this.replyMessageType = replyMessageType;
        this.server = new TsmpServer(pathmonName, serverName);
    }

    @Override
    public U service(T request) {
        try {
            U replyMessage = replyMessageType.newInstance();

            ByteBuffer buf = ByteBuffer.allocate(replyMessage.getLength());
            int result = server.service(request.marshal(), request.getLength(), buf.array());
            replyMessage.unmarshal(buf.array(), replyMessage.getLength());
            
            // ダミー動作用にpathmonNameを返していたが、serverが動作するようになったためコメントアウト
//            byte[] bytes = pathmonName.getBytes(StandardCharsets.UTF_8);
//            try {
//                replyMessage.unmarshal(bytes, bytes.length);
//            } catch (DataConversionException e) {
//                throw new RuntimeException(e);
//            }
            
            return replyMessage;

        } catch (InstantiationException | IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (TsmpSendException e) {
            throw new RuntimeException(e);
        } catch (TsmpServerUnavailableException e) {
            throw new RuntimeException(e);
        } catch (TsmpRoutUnavailableException e) {
            throw new RuntimeException(e);
        } catch (TsmpFileSystemException e) {
            throw new RuntimeException(e);
        } catch (DataConversionException e) {
            throw new RuntimeException(e);
        }
    }
}
