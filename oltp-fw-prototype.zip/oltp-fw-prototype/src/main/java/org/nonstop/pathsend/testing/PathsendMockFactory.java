package org.nonstop.pathsend.testing;

import org.nonstop.pathsend.InputMessage;
import org.nonstop.pathsend.OutputMessage;
import org.nonstop.pathsend.PathsendAccessor;
import org.nonstop.pathsend.PathsendAccessorFactory;

import java.util.Map;
import java.util.function.Function;

public class PathsendMockFactory implements PathsendAccessorFactory {

    private final Map<String, Function<? extends OutputMessage, ? extends InputMessage>> mocks;

    public PathsendMockFactory(Map<String, Function<? extends OutputMessage, ? extends InputMessage>> mocks) {
        this.mocks = mocks;
    }

    @Override
    public <T extends OutputMessage, U extends InputMessage> PathsendAccessor<T, U> create(String pathmonName, String serverName, Class<T> requestMessageType, Class<U> replyMessageType) {
        if (!mocks.containsKey(pathmonName)) {
            throw new IllegalStateException(String.format("対応するモックが設定されていません [%s]", pathmonName));
        }
        return new PathsendMockAccessor(mocks.get(pathmonName + "#" + serverName));
    }
}
