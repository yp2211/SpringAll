package org.nonstop.pathsend;

/**
 * Pathsendアクセサを生成するためのファクトリ
 */
public interface PathsendAccessorFactory {

    <T extends OutputMessage, U extends InputMessage> PathsendAccessor<T, U> create(
            String pathmonName, String serverName, Class<T> requestMessageType, Class<U> replyMessageType);
}
