package org.nonstop.oltp;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertThrows;

class OltpServerTest {

    @Test
    @Disabled("SQL/MXドライバでのDB初期化を組み込んだため")
    void 規定インタフェースを実装したアクションを実行できる() {
        OltpServer.main(new String[]{"nss.oltp.app-name=TestApp"});
    }

    @Test
    void アプリのプロパティファイルが無ければエラー() {
        assertThrows(IllegalStateException.class, () -> OltpServer.main(new String[]{"nss.oltp.app-name=dummy"}));
    }

    @Test
    @Disabled("SQL/MXドライバでのDB初期化を組み込んだため")
    void 規定インタフェースを実装していなければエラー() {
        assertThrows(IllegalStateException.class, () -> OltpServer.main(new String[]{"nss.oltp.app-name=NonImplTestApp"}));
    }
}
