package org.nonstop.oltp.test;

public class NonImplTestAction {

    public NormalOutputMessage apply(NormalInputMessage input) {
        return null;
    }
}
