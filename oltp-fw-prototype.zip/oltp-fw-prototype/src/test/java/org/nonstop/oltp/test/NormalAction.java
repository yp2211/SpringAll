package org.nonstop.oltp.test;

import org.nonstop.oltp.Action;
import org.nonstop.oltp.ApplicationContext;

public class NormalAction implements Action<NormalInputMessage, NormalOutputMessage> {

    @Override
    public NormalOutputMessage execute(ApplicationContext context, NormalInputMessage inputMessage) {
        log(String.format("id: %s , name: %s , age: %d", inputMessage.getId(), inputMessage.getName(), inputMessage.getAge()));

        NormalOutputMessage output = new NormalOutputMessage();
        output.setMessage("レスポンスのテスト");
        return output;
    }

    private void log(String message) {
        String threadName = Thread.currentThread().getName();
        System.out.println("[" + threadName + "] " + message);
    }
}
