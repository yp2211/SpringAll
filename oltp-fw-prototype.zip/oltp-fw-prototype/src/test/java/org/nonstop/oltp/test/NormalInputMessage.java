package org.nonstop.oltp.test;

import com.tandem.ext.util.DataConversionException;
import org.nonstop.pathsend.InputMessage;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;

public class NormalInputMessage implements InputMessage {

    private String id;

    private String name;

    private Integer age;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }

    @Override
    public int getLength() {
        return 0;
    }

    @Override
    public void unmarshal(byte[] data, int i) throws DataConversionException {
        id = new String(data, 0, 3, StandardCharsets.UTF_8);
        name = new String(data, 3, 40, StandardCharsets.UTF_8).trim();
        age = ByteBuffer.wrap(data, 43, 4).getInt();
    }
}
