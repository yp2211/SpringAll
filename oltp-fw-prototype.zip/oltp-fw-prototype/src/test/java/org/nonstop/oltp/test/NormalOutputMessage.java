package org.nonstop.oltp.test;

import com.tandem.ext.util.DataConversionException;
import org.nonstop.pathsend.OutputMessage;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

public class NormalOutputMessage implements OutputMessage {

    private String message;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public int getLength() {
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        os.write(String.format("%-40s", message).getBytes(StandardCharsets.UTF_8), 0, 40);
        return os.toByteArray().length;
    }

    @Override
    public byte[] marshal() {
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        os.write(String.format("%-40s", message).getBytes(StandardCharsets.UTF_8), 0, 40);
        return os.toByteArray();
    }

    @Override
    public byte[] marshal(byte[] bytes) throws DataConversionException {
        ByteArrayOutputStream os = new ByteArrayOutputStream();
        os.write(String.format("%-40s", message).getBytes(StandardCharsets.UTF_8), 0, 40);
        os.write(bytes, 0,  bytes.length);
        return os.toByteArray();
    }
}
