package org.nonstop.pathsend.app;

import com.tandem.ext.util.DataConversionException;
import org.nonstop.pathsend.InputMessage;

public class TestReplyMessage implements InputMessage {

    private byte[] data;

    public byte[] data() {
        return data;
    }

    @Override
    public int getLength() {
        return 7;
    }

    @Override
    public void unmarshal(byte[] data, int i) throws DataConversionException {
        this.data = data;
    }
}
