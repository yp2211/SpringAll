package org.nonstop.pathsend.app;

import com.tandem.ext.util.DataConversionException;
import org.nonstop.pathsend.PathsendAccessor;

public class TestAccessor implements PathsendAccessor<TestRequestMessage, TestReplyMessage> {

    @Override
    public TestReplyMessage service(TestRequestMessage request) {
        TestReplyMessage replyMessage = new TestReplyMessage();
        try {
            // ダミー実装
            replyMessage.unmarshal("replace".getBytes(), "replace".getBytes().length);
        } catch (DataConversionException e) {
            throw new RuntimeException(e);
        }
        return replyMessage;
    }
}
