package org.nonstop.pathsend.testing.app;

import org.nonstop.pathsend.InputMessage;
import org.nonstop.pathsend.OutputMessage;
import org.nonstop.pathsend.testing.PathsendMock;

public class ServerMock implements PathsendMock {

    @Override
    public InputMessage apply(OutputMessage outputMessage) {
        return new TestReplyMessage("fuga".getBytes());
    }
}
