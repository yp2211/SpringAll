package org.nonstop.pathsend.testing;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;
import org.nonstop.oltp.ApplicationContext;
import org.nonstop.pathsend.testing.app.ServerMock;
import org.nonstop.pathsend.testing.app.TestAction;
import org.nonstop.pathsend.testing.app.TestReplyMessage;

class OltpContextExtensionTest {

    @RegisterExtension
    OltpContextExtension oltpContextExtension = new OltpContextExtension();

    @Test
    @Disabled("SQL/MXドライバでのDB初期化を組み込んだため")
    void Pathsendの送信先にモックを設定できる() {
        oltpContextExtension.registerPathsend("hoge", "fuga", new ServerMock());
        ApplicationContext context = oltpContextExtension.crateMockContext("TestApp");

        TestAction action = new TestAction();

        TestReplyMessage replyMessage = action.execute(context, null);

        Assertions.assertArrayEquals("fuga".getBytes(), replyMessage.marshal());
    }

    @Test
    @Disabled("SQL/MXドライバでのDB初期化を組み込んだため")
    void Pathsendの送信先に匿名クラスでモックを設定できる() {
        oltpContextExtension.registerPathsend("hoge", "fuga", input -> new TestReplyMessage("foo".getBytes()));
        ApplicationContext context = oltpContextExtension.crateMockContext("TestApp");

        TestAction action = new TestAction();
        TestReplyMessage replyMessage = action.execute(context, null);

        Assertions.assertArrayEquals("foo".getBytes(), replyMessage.marshal());
    }

}
