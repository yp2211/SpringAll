package org.nonstop.pathsend.testing.app;

import com.tandem.ext.util.DataConversionException;
import org.nonstop.pathsend.InputMessage;
import org.nonstop.pathsend.OutputMessage;

public class TestReplyMessage implements InputMessage, OutputMessage {

    private byte[] data;

    public TestReplyMessage() {
    }

    public TestReplyMessage(byte[] data) {
        this.data = data;
    }

    @Override
    public byte[] marshal() {
        return data;
    }

    @Override
    public byte[] marshal(byte[] bytes) throws DataConversionException {
        return data;
    }

    @Override
    public int getLength() {
        return 4;
    }

    @Override
    public void unmarshal(byte[] data, int i) throws DataConversionException {
        this.data = data;
    }
}
