package org.nonstop.pathsend.app;

import org.nonstop.pathsend.InputMessage;
import org.nonstop.pathsend.OutputMessage;
import org.nonstop.pathsend.PathsendAccessor;
import org.nonstop.pathsend.PathsendAccessorFactory;

public class TestFactory implements PathsendAccessorFactory {

    @Override
    public <T extends OutputMessage, U extends InputMessage> PathsendAccessor<T, U> create(String pathmonName, String serverName, Class<T> requestMessageType, Class<U> replyMessageType) {
        return (PathsendAccessor<T, U>) new TestAccessor();
    }
}
