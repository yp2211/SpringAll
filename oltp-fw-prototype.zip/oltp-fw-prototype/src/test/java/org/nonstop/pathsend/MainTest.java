package org.nonstop.pathsend;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.nonstop.pathsend.app.TestFactory;
import org.nonstop.pathsend.app.TestReplyMessage;
import org.nonstop.pathsend.app.TestRequestMessage;

import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;

class MainTest {

    @BeforeEach
    void setUp() throws Exception {
        System.clearProperty("nss.pathsend.factory-class-name");
        Method method = PathsendRepository.class.getDeclaredMethod("initialize");
        method.setAccessible(true);
        method.invoke(null);
    }

     @Test
     @Disabled("ダミー実装から実際にPathsendを使って動作確認する実装に切り替えたため")
     void PathsendAccessorを取得して実行できる() {
         PathsendAccessor<TestRequestMessage,TestReplyMessage> pathsend = PathsendRepository.get("hoge", TestRequestMessage.class, TestReplyMessage.class);

         TestReplyMessage replyMessage = pathsend.service(null);

         Assertions.assertArrayEquals("hoge".getBytes(StandardCharsets.UTF_8), replyMessage.data());
     }

     @Test
     void PathsendAccessorを切り替えられる() throws Exception {
         System.setProperty("nss.pathsend.factory-class-name", TestFactory.class.getName());
         Method method = PathsendRepository.class.getDeclaredMethod("initialize");
         method.setAccessible(true);
         method.invoke(null);

         PathsendAccessor<TestRequestMessage, TestReplyMessage> pathsend = PathsendRepository.get("hoge", TestRequestMessage.class, TestReplyMessage.class);

         TestReplyMessage replyMessage = pathsend.service(null);

         Assertions.assertArrayEquals("replace".getBytes(), replyMessage.data());
     }

}
