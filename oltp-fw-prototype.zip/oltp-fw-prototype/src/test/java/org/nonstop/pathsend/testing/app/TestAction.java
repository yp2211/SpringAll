package org.nonstop.pathsend.testing.app;

import org.nonstop.oltp.Action;
import org.nonstop.oltp.ApplicationContext;
import org.nonstop.pathsend.PathsendAccessor;

public class TestAction implements Action<TestRequestMessage, TestReplyMessage> {

    @Override
    public TestReplyMessage execute(ApplicationContext context, TestRequestMessage inputMessage) {
        PathsendAccessor<TestRequestMessage, TestReplyMessage> pathsend =
                context.pathsend("hoge", "fuga", TestRequestMessage.class, TestReplyMessage.class);

        return pathsend.service(inputMessage);
    }
}
