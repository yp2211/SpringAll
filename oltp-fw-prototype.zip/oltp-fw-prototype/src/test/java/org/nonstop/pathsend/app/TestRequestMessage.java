package org.nonstop.pathsend.app;

import com.tandem.ext.util.DataConversionException;
import org.nonstop.pathsend.OutputMessage;

public class TestRequestMessage implements OutputMessage {

    private final byte[] data;

    public TestRequestMessage(byte[] data) {
        this.data = data;
    }

    @Override
    public int getLength() {
        return 0;
    }

    @Override
    public byte[] marshal() {
        return data;
    }

    @Override
    public byte[] marshal(byte[] bytes) throws DataConversionException {
        return data;
    }
}
