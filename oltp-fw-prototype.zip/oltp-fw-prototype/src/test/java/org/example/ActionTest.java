package org.example;

import com.tandem.ext.util.DataConversionException;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.RegisterExtension;
import org.nonstop.oltp.ApplicationContext;
import org.nonstop.pathsend.testing.OltpContextExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ActionTest {

    @RegisterExtension
    OltpContextExtension oltpContextExtension = new OltpContextExtension();
    
    @Test
    @Disabled
    void 業務アクションのPathsendをモックで実行する() {
        oltpContextExtension.registerPathsend("hoge", "fuga", outputMessage -> {
            TestPathsendReplyMessage reply = new TestPathsendReplyMessage();
            try {
                reply.unmarshal("mock".getBytes(), "mock".getBytes().length);
            } catch (DataConversionException e) {
                throw new RuntimeException(e);
            }
            return reply;
        });
        ApplicationContext context = oltpContextExtension.crateMockContext("TestApp");

        TestAction sut = new TestAction();
        TestActionInputMessage input = new TestActionInputMessage();
        input.setId("111");
        input.setName("ほげ");
        input.setAge(20);

        TestActionOutputMessage output = sut.execute(context, input);

        assertEquals("response : mock", output.message());
    }
}
